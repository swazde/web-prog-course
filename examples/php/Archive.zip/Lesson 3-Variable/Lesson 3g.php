<!DOCTYPE html>
<html>
<head>
<title> Lesson 3g: : PHP Variables: String</title>
</head>
<body>

<?php

//This is sample 1
$txt="Hello World";
echo $txt;

echo "<br>";
echo "<br>";

//This is sample 2
$string_variable = "Sheikh";
$print_your_name = "My name is $string_variable will print!";
print($print_your_name);

echo "<br>";
echo "<br>";

//This is sample 2
$string_variable = "Sheikh";
$print_your_name = "My name is $string_variable will print!";
echo $print_your_name;

?>

</body>
</html>
