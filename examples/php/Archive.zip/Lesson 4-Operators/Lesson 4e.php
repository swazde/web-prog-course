<html>
<head><title>Lesson 4e: PHP Incrementing/Decrementing Operators</title><head>
<body>
<?php

$x=10;
echo ++$x;
echo "<br>";

$y=10;
echo $y++;
echo "<br>";

$z=5;
echo --$z;
echo "<br>";

$i=5;
echo $i--;
?>  

</body>
</html>