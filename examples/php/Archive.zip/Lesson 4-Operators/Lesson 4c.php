<html>
<head><title>Lesson 4c:String Operators</title><head>
<body>

<?php
//The example below shows the results of using the string operators:


$a = "Hello";
$b = $a . " world!";
echo $b; // outputs Hello world!

echo "<br>";

$x="Hello";
$x .= " world!";
echo $x; // outputs Hello world!

?>  

</body>
</html>