<!DOCTYPE html>
<html>
<head>
<title> Lesson 2a: Basic PHP Syntax</title>
</head>
<body>

<h1>My First PHP Page</h1>




</body>
</html>
