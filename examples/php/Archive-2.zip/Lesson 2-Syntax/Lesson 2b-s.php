<!DOCTYPE html>
<html>
<head>
<title> Lesson 2b: Write a Comment in PHP</title>
</head>

<body>

<?php

// This is a single line comment

#	 This is also a single line comment

/* This is a multiple lines comment block
	 that spans over more than
	 one line
*/



?>

</body>
</html>
