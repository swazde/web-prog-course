<html>
<head>
<title>Lesson 6d: The foreach Loop </title>
</head>

<body>
<?php

// example to list out the values of an array.
$array = array( 1, 2, 3, 4, 5);
foreach( $array as $value )
{
  echo "Value is $value <br />";
}
?>
</body>
</html>